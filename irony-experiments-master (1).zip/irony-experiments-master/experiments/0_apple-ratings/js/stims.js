

var contexts = [2, 3, 4, 5, 10, 20];
